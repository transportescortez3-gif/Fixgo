UPDATE site_settings
SET value = 'Fixxer Expertos'
WHERE key = 'app_name';
