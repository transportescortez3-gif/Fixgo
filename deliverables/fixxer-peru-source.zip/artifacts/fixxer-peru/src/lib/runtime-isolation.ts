const STORAGE_NAMESPACE = "fixxer_peru:";
const STORAGE_PATCHED = "__fixxerPeruStorageIsolated";

function namespacedKey(key: string): string {
  const appKey = key === "fixgo_token" ? "fixxer_token" : key;
  return `${STORAGE_NAMESPACE}${appKey}`;
}

export function installStorageIsolation(): void {
  if (typeof window === "undefined" || typeof Storage === "undefined") return;
  const prototype = Storage.prototype as Storage & { [STORAGE_PATCHED]?: boolean };
  if (prototype[STORAGE_PATCHED]) return;

  const originalGetItem = Storage.prototype.getItem;
  const originalSetItem = Storage.prototype.setItem;
  const originalRemoveItem = Storage.prototype.removeItem;
  const originalClear = Storage.prototype.clear;
  const originalKey = Storage.prototype.key;
  const originalLength = Object.getOwnPropertyDescriptor(Storage.prototype, "length");

  Storage.prototype.getItem = function (key: string): string | null {
    return originalGetItem.call(this, namespacedKey(key));
  };
  Storage.prototype.setItem = function (key: string, value: string): void {
    originalSetItem.call(this, namespacedKey(key), value);
  };
  Storage.prototype.removeItem = function (key: string): void {
    originalRemoveItem.call(this, namespacedKey(key));
  };
  Storage.prototype.clear = function (): void {
    const length = originalLength?.get?.call(this) ?? 0;
    for (let index = length - 1; index >= 0; index -= 1) {
      const key = originalKey.call(this, index);
      if (key?.startsWith(STORAGE_NAMESPACE)) originalRemoveItem.call(this, key);
    }
  };
  Storage.prototype.key = function (index: number): string | null {
    const length = originalLength?.get?.call(this) ?? 0;
    const ownKeys: string[] = [];
    for (let current = 0; current < length; current += 1) {
      const key = originalKey.call(this, current);
      if (key?.startsWith(STORAGE_NAMESPACE)) {
        ownKeys.push(key.slice(STORAGE_NAMESPACE.length));
      }
    }
    return ownKeys[index] ?? null;
  };
  Object.defineProperty(prototype, STORAGE_PATCHED, { value: true });
}

const API_ROUTE = /^\/(?:api|socket\.io)(?:\/|$)/;

function buildApiUrl(pathname: string, search = ""): string {
  const remoteBase = import.meta.env.VITE_FIXXER_PERU_API_BASE_URL?.trim().replace(/\/+$/, "");
  const appBase = (import.meta.env.BASE_URL || "/").replace(/\/+$/, "");
  const prefix = remoteBase || appBase;
  return `${prefix}${pathname}${search}`;
}

function rewriteApiUrl(value: string): string {
  if (typeof window === "undefined" || !value) return value;
  try {
    const url = new URL(value, window.location.origin);
    const isAbsoluteUrl = /^[a-z][a-z\d+.-]*:/i.test(value);
    if (isAbsoluteUrl && url.origin !== window.location.origin) return value;
    if (!API_ROUTE.test(url.pathname)) return value;
    const appBase = (import.meta.env.BASE_URL || "/").replace(/\/+$/, "");
    const remoteBase = import.meta.env.VITE_FIXXER_PERU_API_BASE_URL?.trim().replace(/\/+$/, "");
    const prefix = remoteBase ? new URL(remoteBase).pathname.replace(/\/+$/, "") : appBase;
    if (prefix && (url.pathname === prefix || url.pathname.startsWith(`${prefix}/`))) {
      return value;
    }
    const destinationPath = buildApiUrl(url.pathname, url.search);
    if (remoteBase) {
      return `${new URL(remoteBase).origin}${destinationPath}`;
    }
    return `${destinationPath}${url.hash}`;
  } catch {
    return value;
  }
}

export function installApiRouteIsolation(): void {
  if (typeof window === "undefined") return;

  const originalFetch = window.fetch.bind(window);
  window.fetch = (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    if (typeof input === "string") {
      return originalFetch(rewriteApiUrl(input), init);
    }
    if (input instanceof URL) {
      return originalFetch(new URL(rewriteApiUrl(input.href), window.location.origin), init);
    }
    return originalFetch(
      new Request(new URL(rewriteApiUrl(input.url), window.location.origin), input),
      init,
    );
  };

  const rewriteElementSource = (element: Element, name: string, value: string): string => {
    if (name.toLowerCase() !== "src") return value;
    if (!(element instanceof HTMLImageElement) && !(element instanceof HTMLSourceElement)) return value;
    return rewriteApiUrl(value);
  };

  const originalSetAttribute = Element.prototype.setAttribute;
  Element.prototype.setAttribute = function (name: string, value: string): void {
    return originalSetAttribute.call(this, name, rewriteElementSource(this, name, value));
  };

  for (const prototype of [HTMLImageElement.prototype, HTMLSourceElement.prototype]) {
    const descriptor = Object.getOwnPropertyDescriptor(prototype, "src");
    if (!descriptor?.get || !descriptor?.set) continue;
    Object.defineProperty(prototype, "src", {
      configurable: true,
      enumerable: descriptor.enumerable,
      get: descriptor.get,
      set(value: string) {
        descriptor.set!.call(this, rewriteApiUrl(value));
      },
    });
  }
}
