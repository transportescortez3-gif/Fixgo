#!/usr/bin/env node

import { randomBytes } from "node:crypto";
import { spawn, spawnSync } from "node:child_process";
import { existsSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { tmpdir } from "node:os";
import { fileURLToPath } from "node:url";

const appRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const workspaceRoot = resolve(appRoot, "../..");
const pgData = process.env.FIXXER_PERU_DEV_PGDATA ??
  resolve(tmpdir(), "fixxer-peru-dev-postgres");
const pgPort = process.env.FIXXER_PERU_DEV_PGPORT ?? "55432";
const apiPort = process.env.FIXXER_PERU_API_PORT ?? "4002";
const webPort = "21452";
const databaseName = "fixxer_peru_dev";
const databaseRole = "fixxer_peru_local";
const uploadsDir = resolve(tmpdir(), "fixxer-peru-dev-uploads");
const databaseUrl = `postgresql://${databaseRole}@127.0.0.1:${pgPort}/${databaseName}`;
const pgLog = resolve(tmpdir(), "fixxer-peru-dev-postgres.log");

const sensitiveEnvName =
  /(?:^|_)(?:DATABASE_URL|SESSION_SECRET|PASSWORD|PRIVATE_KEY|API_KEY|TOKEN|CREDENTIAL|SECRET)(?:_|$)/i;
const sensitivePrefixes = [
  "FIXXER_PERU_",
  "VITE_",
  "TWILIO_",
  "FIREBASE_",
  "TBK_",
  "TURN_",
  "METERED_",
  "REDIS_",
  "RESEND_",
  "APNS_",
  "GOOGLE_MAPS_",
  "REPLIT_DB",
  "AWS_",
];

function cleanEnvironment(overrides = {}) {
  const env = { ...process.env };
  for (const key of Object.keys(env)) {
    if (sensitiveEnvName.test(key) || sensitivePrefixes.some((prefix) => key.startsWith(prefix))) {
      delete env[key];
    }
  }
  return { ...env, ...overrides };
}

function run(command, args, options = {}) {
  const result = spawnSync(command, args, {
    cwd: workspaceRoot,
    encoding: "utf8",
    ...options,
  });
  if (result.status !== 0) {
    throw new Error(
      `${command} ${args.join(" ")} failed: ${(result.stderr || result.stdout || "").trim()}`,
    );
  }
  return (result.stdout ?? "").trim();
}

function ensureLocalDatabase() {
  if (!existsSync(resolve(pgData, "PG_VERSION"))) {
    mkdirSync(pgData, { recursive: true });
    run("initdb", [
      "-D", pgData,
      "--username", databaseRole,
      "--auth-local", "trust",
      "--auth-host", "trust",
      "--no-instructions",
    ]);
  }

  const status = spawnSync("pg_ctl", ["-D", pgData, "status"], {
    cwd: workspaceRoot,
    stdio: "ignore",
  });
  if (status.status !== 0) {
    run("pg_ctl", [
      "-D", pgData,
      "-l", pgLog,
      "-o", `-h 127.0.0.1 -p ${pgPort} -c listen_addresses=127.0.0.1 -c unix_socket_directories=${tmpdir()}`,
      "-w", "start",
    ]);
  }

  const databaseExists = run("psql", [
    "-h", "127.0.0.1",
    "-p", pgPort,
    "-U", databaseRole,
    "-d", "postgres",
    "-tAc", `SELECT 1 FROM pg_database WHERE datname = '${databaseName}'`,
  ]);
  if (databaseExists !== "1") {
    run("createdb", [
      "-h", "127.0.0.1",
      "-p", pgPort,
      "-U", databaseRole,
      databaseName,
    ]);
  }
}

const children = [];
let stopping = false;

async function stop(exitCode = 0) {
  if (stopping) return;
  stopping = true;
  await Promise.all(children.map((child) => new Promise((resolveChild) => {
    if (child.exitCode !== null) return resolveChild();
    const forceKill = setTimeout(() => {
      child.kill("SIGKILL");
      resolveChild();
    }, 5000);
    child.once("exit", () => {
      clearTimeout(forceKill);
      resolveChild();
    });
    child.kill("SIGTERM");
  })));
  spawnSync("pg_ctl", ["-D", pgData, "-m", "fast", "-w", "stop"], {
    cwd: workspaceRoot,
    stdio: "ignore",
  });
  process.exit(exitCode);
}

process.on("SIGINT", () => void stop(130));
process.on("SIGTERM", () => void stop(143));

try {
  ensureLocalDatabase();
  mkdirSync(uploadsDir, { recursive: true });

  const apiEnv = cleanEnvironment({
    NODE_ENV: "development",
    PORT: apiPort,
    FIXXER_PERU_DATABASE_URL: databaseUrl,
    FIXXER_PERU_SESSION_SECRET: randomBytes(32).toString("base64url"),
    FIXXER_PERU_UPLOAD_DIR: uploadsDir,
    FIXXER_PERU_FILE_PUBLIC_URL: "/fixxer-peru",
  });
  const api = spawn(
    "pnpm",
    ["exec", "tsx", "artifacts/fixxer-peru/api/src/api.ts"],
    { cwd: workspaceRoot, env: apiEnv, stdio: "inherit" },
  );
  children.push(api);

  const webEnv = cleanEnvironment({
    NODE_ENV: "development",
    PORT: webPort,
    BASE_PATH: "/fixxer-peru/",
    FIXXER_PERU_GOOGLE_MAPS_API_KEY: process.env.FIXXER_PERU_GOOGLE_MAPS_API_KEY ?? "",
    FIXXER_PERU_GOOGLE_MAPS_MAP_ID: process.env.FIXXER_PERU_GOOGLE_MAPS_MAP_ID ?? "",
  });
  const web = spawn(
    "pnpm",
    ["exec", "vite", "--config", "vite.config.ts", "--host", "0.0.0.0", "--port", webPort],
    { cwd: appRoot, env: webEnv, stdio: "inherit" },
  );
  children.push(web);

  for (const child of children) {
    child.once("error", (error) => {
      console.error("[fixxer-peru] No se pudo iniciar un servicio:", error.message);
      void stop(1);
    });
    child.once("exit", (code) => {
      if (!stopping) void stop(code ?? 1);
    });
  }
} catch (error) {
  console.error("[fixxer-peru] Error al iniciar el entorno aislado:", error.message);
  await stop(1);
}
