import{W as o}from"./index-CAWrxv6b.js";const t=[["polygon",{points:"3 11 22 2 13 21 11 13 3 11",key:"1ltx0t"}]],i=o("navigation",t);export{i as N};
