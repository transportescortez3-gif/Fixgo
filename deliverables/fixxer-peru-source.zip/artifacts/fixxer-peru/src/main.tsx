import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { installApiRouteIsolation, installStorageIsolation } from "./lib/runtime-isolation";

installStorageIsolation();
installApiRouteIsolation();

createRoot(document.getElementById("root")!).render(<App />);
