/**
 * The workspace may expose Fixgo's shared environment to every workflow.
 * This API consumes only FIXXER_PERU_* integration settings and clears the
 * unprefixed equivalents before any app modules are imported.
 */
const isolatedKeys = [
  "APNS_BUNDLE_ID",
  "APNS_ENVIRONMENT",
  "APNS_KEY_ID",
  "APNS_PRIVATE_KEY",
  "APNS_TEAM_ID",
  "APP_URL",
  "DATABASE_URL",
  "EMAIL_FROM",
  "FIREBASE_CLIENT_EMAIL",
  "FIREBASE_PRIVATE_KEY",
  "FIREBASE_PROJECT_ID",
  "GOOGLE_MAPS_API_KEY",
  "LOG_LEVEL",
  "METERED_TURN_API_KEY",
  "METERED_TURN_DOMAIN",
  "REDIS_URL",
  "RESEND_API_KEY",
  "SESSION_SECRET",
  "TBK_API_KEY_SECRET",
  "TBK_COMMERCE_CODE",
  "TBK_ENVIRONMENT",
  "TURN_CREDENTIAL",
  "TURN_URLS",
  "TURN_USERNAME",
  "UPLOAD_DIR",
] as const;

for (const key of isolatedKeys) {
  const ownValue = process.env[`FIXXER_PERU_${key}`];
  if (ownValue === undefined || ownValue === "") {
    delete process.env[key];
  } else {
    process.env[key] = ownValue;
  }
}
