DELETE FROM site_settings
WHERE key IN ('commission_rate', 'min_service_price', 'max_service_price');
