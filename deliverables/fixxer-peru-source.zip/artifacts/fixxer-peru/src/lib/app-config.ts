import { Capacitor } from "@capacitor/core";

const configuredApiBase = import.meta.env.VITE_FIXXER_PERU_API_BASE_URL?.trim().replace(/\/+$/, "") ?? "";
const basePath = (import.meta.env.BASE_URL || "/").replace(/\/+$/, "");
const pageOrigin = typeof window === "undefined" ? "" : window.location.origin;

export const APP_URL = configuredApiBase || (Capacitor.isNativePlatform() ? "" : `${pageOrigin}${basePath}`);
export const API_BASE_URL = configuredApiBase || `${pageOrigin}${basePath}`;

const configuredApiUrl = configuredApiBase ? new URL(configuredApiBase) : null;
export const SOCKET_URL = configuredApiUrl
  ? configuredApiUrl.origin
  : Capacitor.isNativePlatform()
    ? APP_URL
    : pageOrigin;
export const SOCKET_PATH = `${configuredApiUrl?.pathname.replace(/\/+$/, "") || basePath}/socket.io`;

export function apiUrl(path: string): string {
  const route = path.startsWith("/") ? path : `/${path}`;
  return `${API_BASE_URL}${route}`;
}