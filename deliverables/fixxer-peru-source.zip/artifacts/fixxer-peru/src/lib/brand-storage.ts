export function migrateBrandStorage(): void {
  // Fixxer Expertos en Perú intentionally never imports keys or sessions from Fixgo.
}

export const AUTH_TOKEN_KEY = "fixgo_token";
export const USER_CACHE_KEY = "fixgo_user";
export const REMEMBER_KEY = "fixgo_remember";
export const KEY_SYNC_DONE_FLAG = "fixgo_e2e_sync_done";

export function getAuthToken(): string | null {
  migrateBrandStorage();
  try {
    return localStorage.getItem(AUTH_TOKEN_KEY) ?? localStorage.getItem("fixxer_token");
  } catch {
    return null;
  }
}
