UPDATE site_settings
SET value = 'Fixxer Perú'
WHERE key = 'app_name';

UPDATE site_settings
SET value = 'Marketplace peruano de servicios locales'
WHERE key = 'app_description';
