import "./lib/isolated-environment";
import "./lib/log-buffer";
import http from "http";
import app from "./app";
import { logger } from "./lib/logger";
import { initSocketIO } from "./lib/socketio";
import { runMigrations } from "./lib/migrate";
import { setMigrationsDone, setMigrationsError } from "./lib/appState";
import { warmSiteSettingsCache } from "./routes/admin";
import { pool } from "./db";
import { purgeExpiredSecuritySelfies } from "./lib/security-selfies";
import { startAdminBlockExpiryScheduler, stopAdminBlockExpiryScheduler } from "./lib/admin-blocks";

const rawPort = process.env.PORT;
if (!rawPort) throw new Error("PORT environment variable is required.");
const port = Number(rawPort);
if (!Number.isFinite(port) || port <= 0) {
  throw new Error(`Invalid PORT: "${rawPort}"`);
}

async function start() {
  const httpServer = http.createServer(app);
  await initSocketIO(httpServer);

  await new Promise<void>((resolve) => {
    httpServer.listen(port, "0.0.0.0", () => {
      logger.info({ port }, "Fixxer Expertos API server listening");
      resolve();
    });
  });

  runMigrations()
    .then(async () => {
      setMigrationsDone();
      logger.info("Migrations completed successfully");
      await warmSiteSettingsCache();
      await purgeExpiredSecuritySelfies();
      startAdminBlockExpiryScheduler();
    })
    .catch((err: unknown) => {
      const error = err instanceof Error ? err : new Error(String(err));
      setMigrationsError(error);
      logger.error(
        { err: error, stack: error.stack },
        `Migration error — server continues but DB may be incomplete: ${error.message}`,
      );
    });

  function shutdown(signal: string) {
    logger.info({ signal }, "Shutting down gracefully...");
    stopAdminBlockExpiryScheduler();
    httpServer.close(async () => {
      try {
        await pool.end();
        logger.info("PostgreSQL pool closed");
      } catch (err) {
        logger.error({ err }, "Error closing PostgreSQL pool");
      }
      process.exit(0);
    });

    setTimeout(() => {
      logger.warn("Forced shutdown after timeout");
      process.exit(1);
    }, 15_000);
  }

  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("unhandledRejection", (reason, promise) => {
    logger.error({ reason, promise: String(promise) }, "Unhandled promise rejection");
  });
  process.on("uncaughtException", (err) => {
    logger.fatal({ err }, "Uncaught exception — the API server will stop");
    process.exit(1);
  });
}

start().catch((err) => {
  logger.error({ err }, "Failed to start API server");
  process.exit(1);
});
