ALTER TYPE payment_method ADD VALUE IF NOT EXISTS 'paypal';
