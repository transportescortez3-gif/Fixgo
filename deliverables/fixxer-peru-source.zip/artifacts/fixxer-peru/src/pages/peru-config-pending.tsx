import { Link } from "wouter";

export default function PeruConfigPending() {
  const path = typeof window === "undefined"
    ? ""
    : window.location.pathname.replace(/^\/fixxer-peru/, "").toLowerCase();
  const identityFlow = path.includes("kyc") || path.includes("security-selfies");
  const financialFlow = /plan|checkout|subscription|commission|coupon|cancellation/.test(path);
  const legalFlow = /terms|privacy|cookies|firmas|eliminar-cuenta|account-deletion/.test(path);

  const title = identityFlow
    ? "Verificación en preparación"
    : financialFlow
      ? "Planes y cobros en preparación"
      : legalFlow
        ? "Documentación en preparación"
        : "Configuración en preparación";
  const message = identityFlow
    ? "El proceso de identidad para Perú aún no está aprobado. No cargues documentos personales desde esta sección."
    : financialFlow
      ? "Fixxer Expertos todavía no tiene planes, cobros ni transferencias habilitados. No realices pagos desde esta sección."
      : legalFlow
        ? "La información y los documentos de Fixxer Expertos en Perú siguen pendientes de aprobación. No se reutilizan documentos de otros países."
        : "Esta herramienta se habilitará cuando esté definida y aprobada la configuración local de Fixxer Expertos.";

  return (
    <main className="min-h-screen bg-background px-5 py-16 text-foreground">
      <section className="mx-auto max-w-xl rounded-3xl border border-border bg-card p-8 shadow-lg sm:p-10">
        <p className="text-sm font-semibold tracking-wide text-primary">FIXXER EXPERTOS</p>
        <h1 className="mt-4 text-3xl font-bold tracking-tight">{title}</h1>
        <p className="mt-4 text-base leading-7 text-muted-foreground">{message}</p>
        <Link
          href="/"
          className="mt-8 inline-flex min-h-11 items-center rounded-xl bg-primary px-5 font-semibold text-primary-foreground hover:bg-primary/90"
        >
          Volver al inicio
        </Link>
      </section>
    </main>
  );
}
