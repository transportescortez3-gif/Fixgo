import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";

function requireJwtSecret(): string {
  const secret = process.env.SESSION_SECRET;
  if (!secret) {
    throw new Error("FIXXER_PERU_SESSION_SECRET must be configured for the isolated API.");
  }
  return secret;
}
const JWT_SECRET = requireJwtSecret();

export function hashPassword(password: string): string {
  return bcrypt.hashSync(password, 10);
}

export function comparePassword(password: string, hash: string): boolean {
  return bcrypt.compareSync(password, hash);
}

export interface TokenPayload {
  id: number;
  email: string;
  role: string;
  originalRole?: string;
}

export function signToken(
  payload: TokenPayload,
  expiresIn: jwt.SignOptions["expiresIn"] = "7d",
): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn });
}

export function verifyToken(token: string): TokenPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as unknown as TokenPayload;
  } catch {
    return null;
  }
}
