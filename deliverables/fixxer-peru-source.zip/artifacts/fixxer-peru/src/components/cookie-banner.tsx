export function CookieBanner() {
  // Cookie disclosures for Peru are not shown until the local policy is approved.
  return null;
}
