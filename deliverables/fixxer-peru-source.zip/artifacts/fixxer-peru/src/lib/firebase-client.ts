export const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIXXER_PERU_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIXXER_PERU_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIXXER_PERU_FIREBASE_PROJECT_ID,
  appId: import.meta.env.VITE_FIXXER_PERU_FIREBASE_APP_ID,
  messagingSenderId: import.meta.env.VITE_FIXXER_PERU_FIREBASE_MESSAGING_SENDER_ID,
};
