import express, { type Express, type Request, type Response, type NextFunction } from "express";
import cors from "cors";
import compression from "compression";
import pinoHttp from "pino-http";
import rateLimit from "express-rate-limit";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

// Confiar en Cloudflare como proxy para que rate-limit use la IP real
app.set("trust proxy", 1);

app.use(compression());

app.use(
  pinoHttp({
    logger,
    autoLogging: {
      ignore: (req) => !req.url?.startsWith("/api"),
    },
    // Loguear 4xx como warn y 5xx como error (antes todo iba como "info")
    customLogLevel(_req, res, err) {
      if (err || res.statusCode >= 500) return "error";
      if (res.statusCode >= 400) return "warn";
      return "info";
    },
    // Incluir el mensaje de error en el log cuando existe
    customSuccessMessage(req, res) {
      if (res.statusCode >= 400) {
        return `${req.method} ${req.url?.split("?")[0]} → ${res.statusCode}`;
      }
      return "request completed";
    },
    customErrorMessage(req, res, err) {
      return `${req.method} ${req.url?.split("?")[0]} → ${res.statusCode} — ${err?.message ?? "error"}`;
    },
    serializers: {
      req(req) {
        return {
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);

const capacitorOrigins = ["https://localhost", "capacitor://localhost", "http://localhost"];
const corsOrigin =
  process.env.NODE_ENV === "production"
    ? [ ...(process.env.APP_URL ? [process.env.APP_URL] : []), ...capacitorOrigins ]
    : true;

app.use(cors({ origin: corsOrigin, credentials: true }));
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));

// Rate limiting general — protege contra abuso y ataques DDoS simples
const generalLimiter = rateLimit({
  windowMs: 60_000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Demasiadas solicitudes. Intenta en un momento." },
  skip: (req) => {
    return req.path === "/api/health" || !req.path.startsWith("/api");
  },
});

// Rate limit más estricto para auth — evita fuerza bruta
const authLimiter = rateLimit({
  windowMs: 15 * 60_000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Demasiados intentos. Espera 15 minutos." },
});

// Rate limit para recuperación de contraseña — evita spam de emails
const passwordLimiter = rateLimit({
  windowMs: 60 * 60_000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Demasiados intentos de recuperación. Espera 1 hora." },
});

app.use("/api", generalLimiter);
app.use("/api/auth/login", authLimiter);
app.use("/api/auth/register", authLimiter);
app.use("/api/auth/forgot-password", passwordLimiter);
app.use("/api/auth/reset-password", passwordLimiter);

const peruConfigPending = (_req: Request, res: Response): void => {
  res.status(503).json({
    code: "PERU_CONFIGURATION_PENDING",
    message: "Este flujo no está habilitado hasta que Fixxer Expertos apruebe su configuración local.",
  });
};
app.use([
  "/api/firmas",
  "/api/kyc",
  "/api/subscriptions",
  "/api/payments",
  "/api/cancellation-charges",
  "/api/admin/commission",
  "/api/admin/kyc",
  "/api/admin/users",
  "/api/admin/coupons",
  "/api/admin/subscriptions",
  "/api/admin/subscription-stats",
  "/api/admin/plans",
  "/api/admin/cancellations",
  "/api/admin/security-selfies",
  "/api/admin/account-deletion-requests",
  "/api/services/:id/cancellation-charge",
  "/api/admin/services/:id/cancellation-charge",
  "/api/services/:id/cancel",
  "/api/services/:id/bank-details",
  "/api/services/:id/transfer-info",
], peruConfigPending);

// The admin user directory exposes unapproved identity fields, so block its
// exact collection route until Peru's review is ready.
app.get("/api/users", peruConfigPending);

// The public landing page reads neutral Peru defaults through this endpoint;
// only writing site settings remains disabled until the content is reviewed.
app.put("/api/admin/site-settings", peruConfigPending);

app.use("/api", router);

// Nunca dejar que una ruta API desconocida caiga en el fallback de la SPA.
// Además de evitar respuestas HTML con status 200 para errores, esto impide
// que sondas como GET /api/.env parezcan endpoints válidos.
app.use("/api", (_req, res): void => {
  res.status(404).json({ error: "API route not found" });
});

// ─── Middleware global de errores ─────────────────────────────────────────────
// Captura cualquier error que llegue con next(err) o de handlers async sin try/catch
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: unknown, req: Request, res: Response, _next: NextFunction): void => {
  const error = err instanceof Error ? err : new Error(String(err));

  // req.log existe gracias a pino-http
  (req as Request & { log?: { error: (...args: unknown[]) => void } }).log?.error(
    { err: error, stack: error.stack },
    `Unhandled error in ${req.method} ${req.url?.split("?")[0]}`,
  ) ?? logger.error({ err: error, stack: error.stack, method: req.method, url: req.url?.split("?")[0] }, "Unhandled error");

  if (res.headersSent) return;

  const status = (err as { status?: number; statusCode?: number })?.status
    ?? (err as { status?: number; statusCode?: number })?.statusCode
    ?? 500;

  res.status(status).json({
    error: process.env.NODE_ENV === "production" ? "Error interno del servidor" : error.message,
  });
});

export default app;
